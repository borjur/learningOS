/*
 * Boris Jurosevic
 * CS 3100
 * Program 1
 * 
 */

- In this code I am showing Thread Priorities and how each one of them starts and finishes.
- My program is done in Java
- Main Class is the "MainClass.java"
- The code is about having 4 threads and as we can see Thread One and Two start at 
the same time, but because thread Two gets the priority and goes first with the method
getPriority() while thread One has to wait. 
- next Thread Three starts because it has a priority over Thread One
- also Thread Four starts because it has a priority over Thread One
- Thread One starts last because it has a Minimal Priority
- Lastly we can see how each thread is finished according to their priorities. 